package org.cap.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Employee {
private int employeeid;
private String employeename;
private double salary;
private int age;
@Autowired

private Address address;
public Employee() {
	System.out.println("Employee no arg constructor");
}

public Employee(int employeeid, String employeename, double salary, int age, Address address) {
	super();
	this.employeeid = employeeid;
	this.employeename = employeename;
	this.salary = salary;
	this.age = age;
	this.address = address;
}

public int getEmployeeid() {
	return employeeid;
}
public void setEmployeeid(int employeeid) {
	this.employeeid = employeeid;
}
public String getEmployeename() {
	return employeename;
}
public void setEmployeename(String employeename) {
	this.employeename = employeename;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}

public void init_method() {
	System.out.println("Init method");
}

public void destroy_method() {
	System.out.println("Destroy method");
}
@Override
public String toString() {
	return "Employee [employeeid=" + employeeid + ", employeename=" + employeename + ", salary=" + salary + ", age="
			+ age + ", address=" + address + "]";
}

/*@Override
public String toString() {
	return "Employee [employeeid=" + employeeid + ", employeename=" + employeename + ", salary=" + salary + ", age="
			+ age + "]";
}*/


/*public String toString() {
	return "Employee [employeeId=" + employeeid + ", employeeName=" + employeename + ", salary=" + salary + ", age="
			+ age + "]";
}  */  

}
