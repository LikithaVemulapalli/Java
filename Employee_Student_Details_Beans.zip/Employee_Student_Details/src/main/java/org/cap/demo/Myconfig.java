package org.cap.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Myconfig {
@Bean
public Student getstudent() {
	Student stud=new Student();
	stud.setStudId(1);
	stud.setStudName("Likitha");
	return stud;
}
}
