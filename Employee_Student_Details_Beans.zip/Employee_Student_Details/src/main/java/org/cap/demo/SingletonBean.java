package org.cap.demo;


/*public class SingletonBean {
	 private PrototypeBean prototypeBean;
	public  SingletonBean(){
          System.out.println("Singleton Bean Instantiated !!");
      }
	public PrototypeBean getPrototypeBean() {
		return prototypeBean;
	}
	public void setPrototypeBean(PrototypeBean prototypeBean) {
		this.prototypeBean = prototypeBean;
	}*/
	

		public abstract class SingletonBean {
			  public SingletonBean()
		      {
		             System.out.println("Singleton Bean Instantiated !!");
		      }
		      public abstract PrototypeBean getPrototypeBean(); 
		} 
		

     

