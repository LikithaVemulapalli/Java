package org.cap.demo;

public class Student {
private int studId;
private String StudName;
public int getStudId() {
	return studId;
}
public void setStudId(int studId) {
	this.studId = studId;
}
public String getStudName() {
	return StudName;
}
public void setStudName(String studName) {
	StudName = studName;
}
@Override
public String toString() {
	return "Student [studId=" + studId + ", StudName=" + StudName + "]";
}
public Student() {
	super();
}

}
