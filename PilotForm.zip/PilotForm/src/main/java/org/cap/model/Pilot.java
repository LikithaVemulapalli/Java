package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
@Entity
public class Pilot {
@Id
@GeneratedValue
private int pilotId;
@NotEmpty(message="Please Enter First name")
private String firstName;
private String lastName;
@Past(message="*Please Enter Past Date")
private Date dateOfbirth;
@Future(message="*Please Enter Future Date")
private Date dateOfJoining;
private Boolean isCertified;
private String Email;
private double salary;
public Pilot() {
	
}

public Pilot(int pilotId, String firstName, String lastName, Date dateOfbirth,Date dateOfJoining,
		Boolean isCertified, double salary, String Email) {
	super();
	this.pilotId = pilotId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.dateOfbirth = dateOfbirth;
	this.dateOfJoining = dateOfJoining;
	this.isCertified = isCertified;
	this.salary = salary;
	this.Email=Email;
}
public int getPilotId() {
	return pilotId;
}
public void setPilotId(int pilotId) {
	this.pilotId = pilotId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}


public Date getDateOfbirth() {
	return dateOfbirth;
}

public void setDateOfbirth(Date dateOfbirth) {
	this.dateOfbirth = dateOfbirth;
}

public Date getDateOfJoining() {
	return dateOfJoining;
}

public void setDateOfJoining(Date dateOfJoining) {
	this.dateOfJoining = dateOfJoining;
}

public Boolean getIsCertified() {
	return isCertified;
}

public void setIsCertified(Boolean isCertified) {
	this.isCertified = isCertified;
}

public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}

public String getEmail() {
	return Email;
}

public void setEmail(String email) {
	Email = email;
}

@Override
public String toString() {
	return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfbirth="
			+ dateOfbirth + ", dateOfJoining=" + dateOfJoining + ", isCertified=" + isCertified + ", salary=" + salary
			+" Email= "+Email + "]";
}

}
